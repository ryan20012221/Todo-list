const API_URL = 'http://localhost:3000/api/todos';

async function fetchTodos() {
  const response = await fetch(API_URL);
  const todos = await response.json();
  const list = document.getElementById('todo-list');
  list.innerHTML = '';
  todos.forEach(todo => {
    const listItem = document.createElement('li');
    listItem.className = todo.completed ? 'completed' : '';
    listItem.innerHTML = `
      ${todo.title}
      <button onclick="toggleComplete(${todo.id})">✔️</button>
      <button onclick="deleteTodo(${todo.id})">❌</button>
    `;
    list.appendChild(listItem);
  });
}

async function addTodo() {
  const title = document.getElementById('new-todo').value;
  await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title })
  });
  fetchTodos();
}

async function toggleComplete(id) {
  await fetch(`${API_URL}/${id}`, { method: 'PUT' });
  fetchTodos();
}

async function deleteTodo(id) {
  await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
  fetchTodos();
}

document.addEventListener('DOMContentLoaded', fetchTodos);
