const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
const Todo = require('./models/Todo');

const app = express();
app.use(cors());
app.use(bodyParser.json());


sequelize.sync().then(() => console.log("Database connected"));


app.get('/api/todos', async (req, res) => {
  const todos = await Todo.findAll();
  res.json(todos);
});

app.post('/api/todos', async (req, res) => {
  const { title } = req.body;
  const todo = await Todo.create({ title });
  res.json(todo);
});

app.put('/api/todos/:id', async (req, res) => {
  const { id } = req.params;
  const todo = await Todo.findByPk(id);
  if (todo) {
    todo.completed = !todo.completed;
    await todo.save();
    res.json(todo);
  } else {
    res.status(404).json({ error: 'Todo not found' });
  }
});

app.delete('/api/todos/:id', async (req, res) => {
  const { id } = req.params;
  const result = await Todo.destroy({ where: { id } });
  if (result) {
    res.status(204).send();
  } else {
    res.status(404).json({ error: 'Todo not found' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));